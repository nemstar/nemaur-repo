#!/bin/bash

if ! which inkscape &> /dev/null; then
	echo "You need inkscape to run this script."
	exit 2
fi

if [ -z "$1" -o -z "$2" ]; then
	echo "Usage: $0 width height [directory]"
	exit 1
fi

SPLASH_WIDTH="$1"
SPLASH_HEIGHT="$2"

if [ -n "$3" ]; then
	cd "$3" || exit 2
	OUT_DIR="$PWD"
	cd "$OLDPWD"
else
	OUT_DIR="$PWD"
fi

mkdir -p "$OUT_DIR/images" || exit 2
cd "$(dirname "$0")"

VERBOSE_IMAGE="images/verbose-${SPLASH_WIDTH}x${SPLASH_HEIGHT}.png"
SILENT_IMAGE="images/silent-${SPLASH_WIDTH}x${SPLASH_HEIGHT}.png"
CONFIG_FILE="$OUT_DIR/${SPLASH_WIDTH}x${SPLASH_HEIGHT}.cfg"
SOURCE_WIDTH="$(inkscape -W 'verbose.svg' 2> /dev/null)"
SOURCE_HEIGHT="$(inkscape -H 'verbose.svg' 2> /dev/null)"

SCALE_CROPX="$(((SOURCE_WIDTH - SOURCE_HEIGHT * SPLASH_WIDTH / SPLASH_HEIGHT) / 2))"
if [ "$SCALE_CROPX" -lt '0' ]; then
	SCALE_CROPX='0'
fi
SCALE_CROPY="$(((SOURCE_HEIGHT - SOURCE_WIDTH * SPLASH_HEIGHT / SPLASH_WIDTH) / 2))"
if [ "$SCALE_CROPY" -lt '0' ]; then
	SCALE_CROPY='0'
fi

SCALE_OPTIONS="-w $SPLASH_WIDTH -h $SPLASH_HEIGHT -a ${SCALE_CROPX}:${SCALE_CROPY}:$((SOURCE_WIDTH - SCALE_CROPX)):$((SOURCE_HEIGHT - SCALE_CROPY))"
inkscape -e "$OUT_DIR/$VERBOSE_IMAGE" $SCALE_OPTIONS 'verbose.svg' 2> /dev/null
inkscape -e "$OUT_DIR/$SILENT_IMAGE" $SCALE_OPTIONS 'silent.svg' 2> /dev/null

LOGO_WIDTH="$(inkscape -W 'logo.svg' 2> /dev/null)"
LOGO_HEIGHT="$(inkscape -H 'logo.svg' 2> /dev/null)"

LOGO_X="$(((SPLASH_WIDTH - LOGO_WIDTH) / 2))"
LOGO_Y="$(((SPLASH_HEIGHT - LOGO_HEIGHT) / 2))"

PROGRESS_WIDTH="$(inkscape -W 'progress.svg' 2> /dev/null)"
PROGRESS_HEIGHT="$(inkscape -H 'progress.svg' 2> /dev/null)"

PROGRESS_X="$(((SPLASH_WIDTH - PROGRESS_WIDTH) / 2))"
PROGRESS_Y="$(((SPLASH_HEIGHT + LOGO_HEIGHT + PROGRESS_HEIGHT) / 2))"

TEXT_SIZE=$((PROGRESS_HEIGHT - 8))

TEXT_X=$((PROGRESS_X + 3))
TEXT_Y=$((SPLASH_HEIGHT - PROGRESS_HEIGHT))

MSGLOG_HEIGHT=$(((TEXT_Y - 3) - (PROGRESS_Y + PROGRESS_HEIGHT + 3)))

MSGLOG_SIZE=$((MSGLOG_HEIGHT / (TEXT_SIZE + 3)))

MSGLOG_Y=$((PROGRESS_Y + PROGRESS_HEIGHT + 3 + (MSGLOG_HEIGHT - MSGLOG_SIZE * (TEXT_SIZE + 3)) / 2))
#****TEXT TO CREATE PROGRESS BAR FROM BELOW SECTION****
#****UNCOMMENT AND ADD BACK IN TO BELOW IF YOU KNOW WHAT YOU ARE DOING AND WANT TO CREATE A PROGRESS BAR DURING BOOT****
# icon images/silent-logo.png $LOGO_X $LOGO_Y
#<type bootup>
#	icon images/progress-empty.png $PROGRESS_X $PROGRESS_Y blendin(500)
#	icon images/progress-full.png $PROGRESS_X $PROGRESS_Y crop <0, 0, 0, ${PROGRESS_HEIGHT}> <0, 0, ${PROGRESS_WIDTH}, ${PROGRESS_HEIGHT}> blendin(500)
#	icon images/progress-fail.png $PROGRESS_X $PROGRESS_Y crop <0, 0, 0, ${PROGRESS_HEIGHT}> <0, 0, ${PROGRESS_WIDTH}, ${PROGRESS_HEIGHT}> svc_start_failed fbsplash-dummy
#</type>
#<type resume>
#	icon images/progress-empty.png $PROGRESS_X $PROGRESS_Y
#	icon images/progress-full.png $PROGRESS_X $PROGRESS_Y crop <0, 0, 0, ${PROGRESS_HEIGHT}> <0, 0, ${PROGRESS_WIDTH}, ${PROGRESS_HEIGHT}>
#</type>
#<type reboot shutdown suspend>
#	icon images/progress-empty.png $PROGRESS_X $PROGRESS_Y
#	icon images/progress-fail.png $PROGRESS_X $PROGRESS_Y svc_stop_failed fbsplash-dummy
#	icon images/progress-full.png $PROGRESS_X $PROGRESS_Y crop <0, 0, ${PROGRESS_WIDTH}, ${PROGRESS_HEIGHT}> <0, 0, 0, ${PROGRESS_HEIGHT}>
#</type>


cat <<EOT > "$CONFIG_FILE" && echo "Generated config file $CONFIG_FILE"
silentpic=$SILENT_IMAGE

log_lines=$MSGLOG_SIZE
log_cols=100
<textbox>
	text silent fonts/Vera.ttf $TEXT_SIZE $TEXT_X left $MSGLOG_Y top #ffffff msglog
</textbox>

box silent $PROGRESS_X $TEXT_Y $((PROGRESS_X + PROGRESS_WIDTH)) $TEXT_Y #2a9cd5
text_font=fonts/Vera.ttf
text_size=$TEXT_SIZE
text_x=$TEXT_X
text_y=$((TEXT_Y + 4))
text_color=#ffffff

pic=$VERBOSE_IMAGE
bgcolor=0
tx=0
ty=0
tw=$SPLASH_WIDTH
th=$SPLASH_HEIGHT
EOT
